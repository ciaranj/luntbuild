package com.luntsys.luntbuild.security;

import javax.naming.*;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sun.jndi.ldap.sasl.LdapSasl;

import java.util.Hashtable;

/**
 * LDAP Authenticator
 *
 * @author lubosp, based on Kira (kec161) contribution
 *
 */
public class LDAPAuthenticator {

    private static Log logger = LogFactory.getLog(LDAPAuthenticator.class);

    private String 	ldapHost = "localhost";
    private int 	ldapPort = 389;
    
    private String 	ldapIdentifyingAttribute = "uid";
    private String  ldapEmailAttribute = "mail";
    private String 	ldapSearchBaseDN = null;
    private String 	ldapSearchScope = "sub";
    private String 	ldapSearchFilter = "(objectclass=*)";
    
    private String 	ldapBindDN = null;
    private String 	ldapBindPassword = null;

    private String 	ldapGroupAttributes = null;
    private String 	ldapRequiredGroups = null;
    private String 	ldapRequiredUsers = null;
    private String 	ldapRequiredDNs = null;
    
    public LDAPAuthenticator () 
    {

    }
    
    public boolean isValid(String value)
    {
    	boolean result = false;
    	if (null != value && value.trim().length()> 0)
    	{
    		result = true;
    	}
    	return result;
    }
    
    public void initialize(ApplicationInternalDAO dao)
    {
    	String value = null;
    	
    	value = dao.getLdapHost().trim();
    	if (isValid(value))
    	{
    		ldapHost = value;
    	}
    	else
    	{
    		logger.warn("Warning: Using default value for ldapHost: " + ldapHost);
    	}
    	
    	value = dao.getLdapPort().trim();
    	if (isValid(value))
    	{
    		try
    		{
    			ldapPort = Integer.parseInt(value);
    		}
    		catch(NumberFormatException nfe)
    		{
    			logger.warn("Error: Invalid port specified: " + value);
    		}
    	}  
    	else
    	{
    		logger.warn("Warning: Using default value for ldapPort: " + ldapPort);
    	}
    	
    	value = dao.getLdapIdentifyingAttribute().trim();
    	if (isValid(value))
    	{
    		ldapIdentifyingAttribute = value;
    	}
    	else
    	{
    		logger.warn("Warning: Using default value for ldapIdentifyingAttribute: " + ldapIdentifyingAttribute);
    	}
    	
    	value = dao.getLdapEmailAttribute().trim();
    	if (isValid(value))
    	{
    		ldapEmailAttribute = value;
    	}   	
    	else
    	{
    		logger.warn("Warning: Using default value for ldapEmailAttribute: " + ldapEmailAttribute);
    	}
    	
    	value = dao.getLdapSearchBaseDN().trim();
    	if (isValid(value))
    	{
    		ldapSearchBaseDN = value;
    	}
    	else
    	{
    		logger.warn("Error: No ldapSearchBaseDN specified!");
    	}
    	
    	value = dao.getLdapSearchScope().trim();
    	if ("one".equalsIgnoreCase(value) || "sub".equalsIgnoreCase(value))
    	{
    		ldapSearchScope = value;
    	}
    	else
    	{
    		logger.warn("Error: Invalid ldapSearchScope specified.  Must be \"one\" or \"sub\"!");
    	}  
    	
    	value = dao.getLdapSearchFilter().trim();
    	if (isValid(value))
    	{
    		ldapSearchFilter = value;
    	}
    	else
    	{
    		logger.warn("Warning: Using default value for ldapSearchFilter: " + ldapSearchFilter);
    	}
    	
    	value = dao.getLdapBindDN().trim();
    	if (isValid(value))
    	{
    		ldapBindDN = value;
    	}
    	
    	value = dao.getLdapBindPassword().trim();
    	if (isValid(value))
    	{
    		ldapBindPassword = value;
    	}
    }
    
    public DirContext getContext(String bindDn, String bindPassword)
    {
    	DirContext context = null;
    	
    	Hashtable env = new Hashtable();
    	env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, "ldap://" + ldapHost + ":" + ldapPort);
        env.put(Context.REFERRAL,"follow");
 
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, bindDn);
        env.put(Context.SECURITY_CREDENTIALS, bindPassword);
        
        try
    	{  
        	context = new InitialDirContext(env);
    	} 
    	catch (Exception ex)
		{
		    logger.warn("Error: Cannot bind to directory!", ex);
		}     
    	
    	return context;
    }
    
    public void closeContext(DirContext context)
    {
    	if(null != context)
    	{
    		try
    		{
    			context.close();
    		}
    		catch(Exception ex)
    		{
    			logger.warn("Error: Error closing context",ex);
    		}
    	}
    }
    
    public SearchResult lookupUser(String user)
    {
    	SearchResult userObj = null;
    	DirContext context = getContext(ldapBindDN, ldapBindPassword);
    	if (null != context)
    	{
    		SearchControls controls = new SearchControls();
    		controls.setReturningObjFlag (true);
    		if("sub".equalsIgnoreCase(ldapSearchScope))
    		{
    			controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
    		}
    		else
    		{
    			controls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
    		}
    		           
            String filter = "(&(" + ldapSearchFilter + ")(" + ldapIdentifyingAttribute + "=" + user + "))";
            NamingEnumeration results = null;
            try
            {
            	results = context.search(ldapSearchBaseDN, filter, controls);
 
            	if(results.hasMore()) 
                {
                	userObj = (SearchResult)results.next();
                }
                
                if(results.hasMore())
                {
                	logger.warn("Error: Multiple users found!");
                	userObj = null;
                }
            }
            catch(Exception ex)
            {
            	logger.warn("Error: Search failed", ex);
            }
            finally
            {
            	closeContext(context);
            }
    	}
    	return userObj;
    }
    
    public boolean authorizeUser(SearchResult user)
    {
    	boolean result = true;
    	
    	
    	return result;
    }
    
    public boolean authenticateUser(String dn, String password) 
    {
    	boolean result = false;
    	DirContext context = getContext(dn,password);
    	if(null != context)
    	{
    		result = true;
    		closeContext(context);    			
    	}
    	return result;
    }
 
    /**
     * @param user
     * @param password
     * @return true if authenticated
     */
    public boolean authenticate(String user, String password)
    {
    	boolean authenticated = false;
    	
    	SearchResult userObj = lookupUser(user);
    	
    	if(userObj != null)
    	{
    		authenticated = authenticateUser(userObj.getNameInNamespace(),password) && authorizeUser(userObj);
    	}
    	
    	return authenticated;
    }

    /**
     * @param user
     * @param password
     * @param emailAttrName
     * @return email or null
     */
    public String lookupEmail(String user) 
    {
    	String email = null;
    	SearchResult userObj = lookupUser(user);
    	if(null != userObj)
    	{
	    	Attributes attrs = userObj.getAttributes();
	    	if(null != attrs)
	    	{
		        Attribute attr = attrs.get(ldapEmailAttribute);
		        if (attr != null)
		        {
		        	try
		        	{
		        		email = (String)attr.get();
		        	}
		        	catch(Exception ex)
		        	{
		        		logger.warn("Error: Unable to get email address",ex);
		        	}
		        }
	    	}
    	}
        return email;
    }
}
