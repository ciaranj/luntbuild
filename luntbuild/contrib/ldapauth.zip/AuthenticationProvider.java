package com.luntsys.luntbuild.security;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.acegisecurity.providers.dao.AbstractUserDetailsAuthenticationProvider;
import net.sf.acegisecurity.providers.dao.AuthenticationDao;
import net.sf.acegisecurity.providers.dao.SaltSource;

import net.sf.acegisecurity.providers.encoding.PasswordEncoder;
import net.sf.acegisecurity.providers.encoding.PlaintextPasswordEncoder;

import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.UsernamePasswordAuthenticationToken;

import net.sf.acegisecurity.AuthenticationCredentialsNotFoundException;
import net.sf.acegisecurity.AuthenticationException;
import net.sf.acegisecurity.BadCredentialsException;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;
import net.sf.acegisecurity.AuthenticationServiceException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import net.sf.acegisecurity.DisabledException;
import net.sf.acegisecurity.AccountExpiredException;
import net.sf.acegisecurity.CredentialsExpiredException;

import net.sf.acegisecurity.Authentication;
import org.springframework.util.Assert;

import com.luntsys.luntbuild.db.Project;
import com.luntsys.luntbuild.db.Role;
import com.luntsys.luntbuild.db.User;
import com.luntsys.luntbuild.notifiers.EmailNotifier;
import com.luntsys.luntbuild.notifiers.TemplatedNotifier;
import com.luntsys.luntbuild.utility.Luntbuild;

import net.sf.acegisecurity.providers.dao.UserCache;
import net.sf.acegisecurity.providers.dao.cache.NullUserCache;

/**
 * LDAP Authentication Provider
 *
 * @author Lubos Pochman based on contribution from Kira (kec161)
 *
 */
public class AuthenticationProvider extends AbstractUserDetailsAuthenticationProvider  {

    private static transient final Log logger = LogFactory.getLog(AuthenticationProvider.class);

    private AuthenticationDao authenticationDao;
    private PasswordEncoder passwordEncoder = new PlaintextPasswordEncoder();
    private SaltSource saltSource;
    private boolean hideUserNotFoundExceptions = true;
    private UserCache userCache = new NullUserCache();
    private boolean forcePrincipalAsString = false;
    private UserDetails userAuth = null;
    private LDAPAuthenticator ldapAuthenticator= new LDAPAuthenticator();

    /**
     * @param authenticationDao
     */
    public void setAuthenticationDao(AuthenticationDao authenticationDao) {
        this.authenticationDao = authenticationDao;
        if (this.authenticationDao instanceof ApplicationInternalDAO)
        {
        	ldapAuthenticator.initialize((ApplicationInternalDAO)authenticationDao);
        }
    }

    /**
     * @return authentication Dao
     */
    public AuthenticationDao getAuthenticationDao() {
        return this.authenticationDao;
    }

    /**
     * By default the <code>DaoAuthenticationProvider</code> throws a
     * <code>BadCredentialsException</code> if a username is not found or the
     * password is incorrect. Setting this property to <code>false</code> will
     * cause <code>UsernameNotFoundException</code>s to be thrown instead for
     * the former. Note this is considered less secure than throwing
     * <code>BadCredentialsException</code> for both exceptions.
     *
     * @param hideUserNotFoundExceptions set to <code>false</code> if you wish
     *        <code>UsernameNotFoundException</code>s to be thrown instead of
     *        the non-specific <code>BadCredentialsException</code> (defaults
     *        to <code>true</code>)
     */
    public void setHideUserNotFoundExceptions(
        boolean hideUserNotFoundExceptions) {
        this.hideUserNotFoundExceptions = hideUserNotFoundExceptions;
    }

    /**
     * @return isHideUserNotFoundExceptions
     */
    public boolean isHideUserNotFoundExceptions() {
        return this.hideUserNotFoundExceptions;
    }

    /**
     * Sets the PasswordEncoder instance to be used to encode and validate
     * passwords. If not set, {@link PlaintextPasswordEncoder} will be used by
     * default.
     *
     * @param passwordEncoder The passwordEncoder to use
     */
    public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * @return PasswordEncoder
     */
    public PasswordEncoder getPasswordEncoder() {
        return this.passwordEncoder;
    }

    /**
     * The source of salts to use when decoding passwords.  <code>null</code>
     * is a valid value, meaning the <code>DaoAuthenticationProvider</code>
     * will present <code>null</code> to the relevant
     * <code>PasswordEncoder</code>.
     *
     * @param saltSource to use when attempting to decode passwords via  the
     *        <code>PasswordEncoder</code>
     */
    public void setSaltSource(SaltSource saltSource) {
        this.saltSource = saltSource;
    }

    /**
     * @return SaltSource
     */
    public SaltSource getSaltSource() {
        return this.saltSource;
    }


    protected void additionalAuthenticationChecks(UserDetails userDetails,
            UsernamePasswordAuthenticationToken authentication)
    throws AuthenticationException {
        Object salt = null;
        this.userAuth = userDetails;

        String name = authentication.getPrincipal().toString().trim();
        String password = authentication.getCredentials().toString().trim();

        // Handle sys admin
        if (name.equals("luntbuild") || name.equals("anonymous")) {
            if (userDetails == null)
                throw new AuthenticationServiceException(
                "AuthenticationDao returned null, which is an interface contract violation");

            if (this.saltSource != null) {
                salt = this.saltSource.getSalt(userDetails);
            }

            if (!this.passwordEncoder.isPasswordValid(userDetails.getPassword(),
                    authentication.getCredentials().toString(), salt)) {
                throw new BadCredentialsException("Bad credentials: "
                        + userDetails.toString());
            }
            return;
        }

        // Get Luntbuild authenticator
        if (!(this.authenticationDao instanceof ApplicationInternalDAO)) return;

        ApplicationInternalDAO luntbuildAuthenticator = (ApplicationInternalDAO)this.authenticationDao;

        boolean useLdapAuthentication = new Boolean(luntbuildAuthenticator.getUseLdapAuthentication()).booleanValue();
        
        boolean useLuntbuildOnFail =
            new Boolean(luntbuildAuthenticator.getLdapUseLuntbuildOnFail()).booleanValue();
        boolean canCreateProject =
            new Boolean(luntbuildAuthenticator.getLdapCanCreateProject()).booleanValue();
        boolean canViewProject =
            new Boolean(luntbuildAuthenticator.getLdapCanViewProject()).booleanValue();
        boolean canBuildProject =
            new Boolean(luntbuildAuthenticator.getLdapCanBuildProject()).booleanValue();
        boolean doCreateLuntbuildUser =
            new Boolean(luntbuildAuthenticator.getLdapCreateLuntbuildUser()).booleanValue();


        // LDAP not specified use Luntbuild authentication
        if (!useLdapAuthentication) {
            if (useLuntbuildOnFail && userDetails != null && userDetails.getPassword().equals(password)) {
                logger.info("Luntbuild User Authentication (user: " + name + ") SUCCESS\n");
                return;
            }
            authentication.setAuthenticated(false);
            logger.warn("User Authentication (user: " + name + ") FAILURE\n");
            throw new AuthenticationCredentialsNotFoundException("Cannot authenticate user " + name);
        }
       

        // LDAP specified, use it
        if (ldapAuthenticator.authenticate(name, password)){
            // Load Luntbuild user if exist, or create new user
            if (doCreateLuntbuildUser) {
                if (!Luntbuild.getDao().isUserExist(name)) {
                    // create user
                    User user = new User();
                    user.setName(name);
                    user.setCanCreateProject(canCreateProject);
                    user.setDecryptedPassword(password);
                    // set email

                    String email = ldapAuthenticator.lookupEmail(name);
                    if (null != email)
                    {
	                    Map contacts = user.getContacts();
	                    List notifiers = Luntbuild.getNotifierInstances(Luntbuild.notifiers);
	                    EmailNotifier emailNotifier = null;
	                    for (Iterator iter = notifiers.iterator(); iter.hasNext();) {
	                        TemplatedNotifier cz = (TemplatedNotifier) iter.next();
	                        if (cz instanceof EmailNotifier) {
	                            emailNotifier = (EmailNotifier)cz;
	                            break;
	                        }
	                    }
	                    if (emailNotifier != null) {
	                        contacts.put(emailNotifier.getKey(), email);
	                        user.setContacts(contacts);
	                    }
                    }

                    Luntbuild.getDao().saveUserInternal(user);

                    if (canCreateProject) setProjectsPrivileges(user, Role.LUNTBUILD_PRJ_ADMIN);
                    if (canBuildProject) setProjectsPrivileges(user, Role.LUNTBUILD_PRJ_BUILDER);
                    if (canViewProject) setProjectsPrivileges(user, Role.LUNTBUILD_PRJ_VIEWER);

                    userDetails = this.authenticationDao.loadUserByUsername(name);

                    this.userAuth = userDetails;

                } else {
                    // Update password
                    User user = Luntbuild.getDao().loadUser(name);
                    user.setDecryptedPassword(password);
                }

            } else {
                this.userAuth =
                    authorizeUser(name, password, canCreateProject, canBuildProject, canViewProject);
            }
            logger.info("LDAP User Authentication (user: " + name + ") SUCCESS\n");
            return;
        } else {
            if (useLuntbuildOnFail &&
                    userDetails != null && userDetails.getPassword().equals(password)) {
                logger.info("Luntbuild User Authentication (user: " + name + ") SUCCESS\n");
                return;
            }
            authentication.setAuthenticated(false);
            logger.warn("User Authentication (user: " + name + ") FAILURE\n");
            throw new AuthenticationCredentialsNotFoundException(
                    "Cannot authenticate user " + name + " against LDAP");
        }
    }

    private void setProjectsPrivileges(User user, String role) {
        Iterator it = Luntbuild.getDao().loadProjectsInternal().iterator();
        while (it.hasNext()) {
            Project project = (Project) it.next();
            List origUsers = project.getMappedRolesUserList(role);
            ArrayList users = new ArrayList();
            users.addAll(origUsers);
            users.add(user);
            project.putMappedRolesUserList(users, role);
            Luntbuild.getDao().saveProjectInternal(project);
        }
    }

    private UserDetails authorizeUser(String name, String password,
            boolean canCreateProject, boolean canBuildProject, boolean canViewProject) {
        UserDetails userdetails = null;
        GrantedAuthority authorities[] = null;

        int authSize = 1;
        if (canCreateProject) authSize++;
        if (canViewProject) authSize++;
        if (canBuildProject) authSize++;

        authorities = new GrantedAuthorityImpl[authSize];

        int ix = 0;
        authorities[ix++] = new GrantedAuthorityImpl(Role.ROLE_AUTHENTICATED);
        if (canCreateProject)
            authorities[ix++] = new GrantedAuthorityImpl("LUNTBUILD_PRJ_ADMIN_0");
        if (canViewProject)
            authorities[ix++] = new GrantedAuthorityImpl("LUNTBUILD_PRJ_VIEWER");
        if (canBuildProject)
            authorities[ix++] = new GrantedAuthorityImpl("LUNTBUILD_PRJ_BUILDER");

        userdetails =
            new net.sf.acegisecurity.providers.dao.User(name, password, true, true, true, authorities);

        return userdetails;
    }

    protected final UserDetails retrieveUser(String username,
            UsernamePasswordAuthenticationToken authentication)
    throws AuthenticationException {
        UserDetails loadedUser;

        try {
            loadedUser = this.authenticationDao.loadUserByUsername(username);
        } catch (UsernameNotFoundException notFound) {
            return null;
        } catch (DataAccessException repositoryProblem) {
            throw new AuthenticationServiceException(repositoryProblem
                    .getMessage(), repositoryProblem);
        }

        if (loadedUser == null) {
            throw new AuthenticationServiceException(
            "AuthenticationDao returned null, which is an interface contract violation");
        }

        return loadedUser;
    }

    public Authentication authenticate(Authentication authentication)
    throws AuthenticationException {
        Assert.isInstanceOf(UsernamePasswordAuthenticationToken.class,
                authentication,
        "Only UsernamePasswordAuthenticationToken is supported");

        // Determine username
        String username = (authentication.getPrincipal() == null)
        ? "NONE_PROVIDED" : authentication.getName();

        boolean cacheWasUsed = true;
        UserDetails user = this.userCache.getUserFromCache(username);

        if (user == null) {
            cacheWasUsed = false;
            user = retrieveUser(username, (UsernamePasswordAuthenticationToken) authentication);
        }

        // This check must come here, as we don't want to tell users
        // about account status unless they presented the correct credentials
        try {
            additionalAuthenticationChecks(user,
                    (UsernamePasswordAuthenticationToken) authentication);
        } catch (AuthenticationException exception) {
            // There was a problem, so try again after checking we're using latest data
            cacheWasUsed = false;
            this.userAuth = null;
            user = retrieveUser(username,
                    (UsernamePasswordAuthenticationToken) authentication);
            additionalAuthenticationChecks(user,
                    (UsernamePasswordAuthenticationToken) authentication);
        }
        if (user == null) user = this.userAuth;
        if (user == null) {
            throw new UsernameNotFoundException("User " + username + " not found");
        }

        if (!user.isEnabled()) {
            throw new DisabledException("User is disabled");
        }

        if (!user.isAccountNonExpired()) {
            throw new AccountExpiredException("User account has expired");
        }

        if (!user.isCredentialsNonExpired()) {
            throw new CredentialsExpiredException("User credentials have expired");
        }

        if (!cacheWasUsed) {
            this.userCache.putUserInCache(user);
        }

        Object principalToReturn = user;

        if (this.forcePrincipalAsString) {
            principalToReturn = user.getUsername();
        }

        return createSuccessAuthentication(principalToReturn, authentication, user);
    }
}

