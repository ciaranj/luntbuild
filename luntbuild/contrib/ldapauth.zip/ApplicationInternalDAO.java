/**
 * Copyright luntsys (c) 2004-2005,
 * Date: 2004-10-21
 * Time: 16:03:58
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met: 1.
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer. 2. Redistributions in
 * binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other
 * materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

package com.luntsys.luntbuild.security;

import com.luntsys.luntbuild.db.RolesMapping;
import com.luntsys.luntbuild.db.Role;
import com.luntsys.luntbuild.utility.Luntbuild;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.AuthenticationDao;
import net.sf.acegisecurity.providers.dao.User;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;

import java.util.Iterator;

public class ApplicationInternalDAO implements AuthenticationDao 
{
	
	private String  useLdapAuthentication = "false";
	
    private String 	ldapHost = "localhost";
    private String 	ldapPort = "389";
    
    private String 	ldapIdentifyingAttribute = "uid";
    private String  ldapEmailAttribute = "mail";
    
    private String 	ldapSearchBaseDN = null;
    private String 	ldapSearchScope = "sub";
    private String 	ldapSearchFilter = "(objectclass=*)";
    
    private String 	ldapBindDN = null;
    private String 	ldapBindPassword = null;

    private String 	ldapGroupAttributes = null;
    private String 	ldapRequiredGroups = null;
    private String 	ldapRequiredUsers = null;
    private String 	ldapRequiredDNs = null;
    
    private String  ldapUseLuntbuildOnFail;
    private String  ldapCanCreateProject;
    private String  ldapCanViewProject;
    private String  ldapCanBuildProject;
    private String  ldapCreateLuntbuildUser;


    private static transient final Log logger = LogFactory.getLog(ApplicationInternalDAO.class);

    /**
     * @see net.sf.acegisecurity.providers.dao.AuthenticationDao#loadUserByUsername(java.lang.String)
     */
    public UserDetails loadUserByUsername(String username)
    throws UsernameNotFoundException, DataAccessException {
		if (Luntbuild.isEmpty(username))
			throw new UsernameNotFoundException("");
        UserDetails userdetails = null;
        GrantedAuthority authorities[] = null;
        String password = null;

        try
        {
            // try to retrieve user credentials from local db
            com.luntsys.luntbuild.db.User luntUser = Luntbuild.getDao().loadUser(username);

            password = luntUser.getDecryptedPassword();

            int authSize = 1;
			if (luntUser.isCanCreateProject())
				authSize++;

            if ( luntUser.getRolesMappings() != null)
            {
                authSize += luntUser.getRolesMappings().size();
            }

            authorities = new GrantedAuthorityImpl[authSize];

            int ix = 0;
			authorities[ix++] = new GrantedAuthorityImpl(Role.ROLE_AUTHENTICATED);
			if (luntUser.isCanCreateProject())
				authorities[ix++] = new GrantedAuthorityImpl("LUNTBUILD_PRJ_ADMIN_0");

            if ( luntUser.getRolesMappings() != null)
            {
                Iterator iterator = luntUser.getRolesMappings().iterator();

                while (iterator.hasNext())
                {
                    RolesMapping mappedRole = (RolesMapping)iterator.next();

                    String role = mappedRole.getRole().getName();

                    if ( role.indexOf("PRJ") > 0)
                    {
                        role += "_"+mappedRole.getProject().getId();
                    }

                    authorities[ix] =  new GrantedAuthorityImpl(role);
                    ix++;
                }
            }
        }
        catch (Exception x)
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("user with loginname ["+username+"] could not be found in db");
            }

            throw new UsernameNotFoundException("username ["+username+"] could not be found in db");
        }

        userdetails = new User(username, password, true, true, true, authorities);

        return userdetails;
    }

    /**
     * @param useLdapAuthentication
     */
    public void setUseLdapAuthentication (String useLdapAuthentication){
        this.useLdapAuthentication = useLdapAuthentication;
    }

    /**
     * @return Returns the useLdapAuthentication.
     */
    public final String getUseLdapAuthentication() {
        return this.useLdapAuthentication;
    }    
    
    /**
     * @param ldapHost
     */
    public void setLdapHost (String ldapHost){
        this.ldapHost = ldapHost;
    }

    /**
     * @return Returns the ldapHost.
     */
    public final String getLdapHost() {
        return this.ldapHost;
    }
    
    /**
     * @param ldapPort
     */
    public void setLdapPort (String ldapPort){
        this.ldapPort = ldapPort;
    }

    /**
     * @return Returns the ldapPort.
     */
    public final String getLdapPort() {
        return this.ldapPort;
    }
    
    /**
     * @param ldapIdentifyingAttribute
     */
    public final void setLdapIdentifyingAttribute(String ldapIdentifyingAttribute) {
        this.ldapIdentifyingAttribute = ldapIdentifyingAttribute;
    }

    /**
     * @return Returns the ldapIdentifyingAttribute.
     */
    public final String getLdapIdentifyingAttribute() {
        return this.ldapIdentifyingAttribute;
    }
    
    /**
     * @param ldapSearchBaseDN
     */
    public final void setLdapSearchBaseDN(String ldapSearchBaseDN) {
        this.ldapSearchBaseDN = ldapSearchBaseDN;
    }    
  
    /**
     * @return Returns the ldapSearchBaseDN.
     */
    public final String getLdapSearchBaseDN() {
        return this.ldapSearchBaseDN;
    }
    
    /**
     * @param ldapSearchScope
     */
    public final void setLdapSearchScope(String ldapSearchScope) {
        this.ldapSearchScope = ldapSearchScope;
    }    

    /**
     * @return Returns the ldapSearchScope.
     */
    public final String getLdapSearchScope() {
        return this.ldapSearchScope;
    }
    
    /**
     * @param ldapSearchFilter
     */
    public final void setLdapSearchFilter(String ldapSearchFilter) {
        this.ldapSearchFilter = ldapSearchFilter;
    }
 
    /**
     * @return Returns the ldapSearchFilter.
     */
    public final String getLdapSearchFilter() {
        return this.ldapSearchFilter;
    }
    
    /**
     * @param ldapBindDN
     */
    public final void setLdapBindDN(String ldapBindDN) {
        this.ldapBindDN = ldapBindDN;
    }
 
    /**
     * @return Returns the ldapBindDN.
     */
    public final String getLdapBindDN() {
        return this.ldapBindDN;
    }
    
    /**
     * @param ldapBindPassword
     */
    public final void setLdapBindPassword(String ldapBindPassword) {
        this.ldapBindPassword = ldapBindPassword;
    }    

    /**
     * @return Returns the ldapBindPassword.
     */
    public final String getLdapBindPassword() {
        return this.ldapBindPassword;
    }
    
    /**
     * @param ldapGroupAttributes
     */
    public final void setLdapGroupAttributes(String ldapGroupAttributes) {
        this.ldapGroupAttributes = ldapGroupAttributes;
    }    
 
    /**
     * @return Returns the ldapGroupAttributes.
     */
    public final String getLdapGroupAttributes() {
        return this.ldapGroupAttributes;
    }
    
    /**
     * @param ldapRequiredGroups
     */
    public final void setLdapRequiredGroups(String ldapRequiredGroups) {
        this.ldapRequiredGroups = ldapRequiredGroups;
    }

    /**
     * @return Returns the ldapRequiredGroups.
     */
    public final String getLdapRequiredGroups() {
        return this.ldapRequiredGroups;
    }
    
    /**
     * @param ldapRequiredUsers
     */
    public final void setLdapRequiredUsers(String ldapRequiredUsers) {
        this.ldapRequiredUsers = ldapRequiredUsers;
    }

    /**
     * @return Returns the ldapRequiredUsers.
     */
    public final String getLdapRequiredUsers() {
        return this.ldapRequiredUsers;
    }      
    
    /**
     * @param ldapRequiredDNs
     */
    public final void setLdapRequiredDNs(String ldapRequiredDNs) {
        this.ldapRequiredDNs = ldapRequiredDNs;
    }

    /**
     * @return Returns the ldapRequiredDNs.
     */
    public final String getLdapRequiredDNs() {
        return this.ldapRequiredDNs;
    }    
    
    /**
     * @param ldapEmailAttribute
     */
    public final void setLdapEmailAttribute(String ldapEmailAttribute) {
        this.ldapEmailAttribute = ldapEmailAttribute;
    }    
    
    /**
     * @return Returns the ldapEmailAttribute.
     */
    public final String getLdapEmailAttribute() {
        return this.ldapEmailAttribute;
    }
    
    /**
     * @return Returns the ldapUseLuntbuildOnFail.
     */
    public final String getLdapUseLuntbuildOnFail() {
        return this.ldapUseLuntbuildOnFail;
    }

    /**
     * @param ldapUseLuntbuildOnFail The ldapUseLuntbuildOnFail to set.
     */
    public final void setLdapUseLuntbuildOnFail(String ldapUseLuntbuildOnFail) {
        this.ldapUseLuntbuildOnFail = ldapUseLuntbuildOnFail;
    }

    /**
     * @return Returns the ldapCanCreateProject.
     */
    public final String getLdapCanCreateProject() {
        return this.ldapCanCreateProject;
    }

    /**
     * @param ldapCanCreateProject The ldapCanCreateProject to set.
     */
    public final void setLdapCanCreateProject(String ldapCanCreateProject) {
        this.ldapCanCreateProject = ldapCanCreateProject;
    }
  
    /**
     * @return Returns the ldapCreateLuntbuildUser.
     */
    public final String getLdapCreateLuntbuildUser() {
        return this.ldapCreateLuntbuildUser;
    }

   
    /**
     * @param ldapCreateLuntbuildUser The ldapCreateLuntbuildUser to set.
     */
    public final void setLdapCreateLuntbuildUser(String ldapCreateLuntbuildUser) {
        this.ldapCreateLuntbuildUser = ldapCreateLuntbuildUser;
    }

    /**
     * @return Returns the ldapCanBuildProject.
     */
    public final String getLdapCanBuildProject() {
        return this.ldapCanBuildProject;
    }

    /**
     * @param ldapCanBuildProject The ldapCanBuildProject to set.
     */
    public final void setLdapCanBuildProject(String ldapCanBuildProject) {
        this.ldapCanBuildProject = ldapCanBuildProject;
    }

    /**
     * @return Returns the ldapCanViewProject.
     */
    public final String getLdapCanViewProject() {
        return this.ldapCanViewProject;
    }

    /**
     * @param ldapCanViewProject The ldapCanViewProject to set.
     */
    public final void setLdapCanViewProject(String ldapCanViewProject) {
        this.ldapCanViewProject = ldapCanViewProject;
    }
    
}
